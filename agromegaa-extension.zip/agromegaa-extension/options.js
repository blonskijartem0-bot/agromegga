'use strict';
const $ = id => document.getElementById(id);
const msg = (t, cls) => { $('status').textContent = t; $('status').className = 'status ' + (cls || ''); };

async function load() {
  const s = await chrome.storage.local.get({ clearSession: true, siteOrigin: '' });
  $('clear').checked = s.clearSession;
  if (s.siteOrigin) { $('url').value = s.siteOrigin; msg('Підключено: ' + s.siteOrigin, 'ok'); }
  else msg('Сайт ще не підключено.');
}

$('clear').onchange = () => chrome.storage.local.set({ clearSession: $('clear').checked });

$('connect').onclick = async () => {
  let u;
  try { u = new URL($('url').value.trim()); } catch { return msg('Введи повну адресу, наприклад https://твійнік.github.io/agromegga/', 'err'); }
  if (!(u.protocol === 'https:' || (u.protocol === 'http:' && u.hostname === 'localhost'))) return msg('Потрібна адреса, що починається з https://', 'err');
  const granted = await chrome.permissions.request({ origins: [u.origin + '/*'] });
  if (!granted) return msg('Доступ до сайту не надано. Спробуй ще раз і натисни «Дозволити».', 'err');
  const r = await chrome.runtime.sendMessage({ type: 'REGISTER_SITE', origin: u.origin });
  if (r && r.ok) msg('Підключено: ' + u.origin + '. Онови сторінку сайту, і біля меню зʼявиться позначка розширення.', 'ok');
  else msg('Не вдалося підключити: ' + ((r && r.error) || 'невідома помилка'), 'err');
};

$('disconnect').onclick = async () => {
  await chrome.runtime.sendMessage({ type: 'UNREGISTER_SITE' });
  $('url').value = '';
  msg('Сайт відключено.');
};

load();
