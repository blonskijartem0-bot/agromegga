'use strict';
/* agromegaa автовхід — фоновий скрипт.
   Отримує від сайту (через content-site.js) команду LOGIN, відкриває сторінку входу платформи
   й віддає логін та пароль лише скрипту content-login.js тієї вкладки.
   Паролі зберігаються тільки в пам'яті браузера (storage.session) і не довше 3 хвилин. */

const LOGIN = {
  tiktok:    { url: 'https://www.tiktok.com/login/phone-or-email/email', cookieDomains: ['tiktok.com'] },
  instagram: { url: 'https://www.instagram.com/accounts/login/',         cookieDomains: ['instagram.com'] },
  twitter:   { url: 'https://x.com/i/flow/login',                         cookieDomains: ['x.com', 'twitter.com'] },
  // YouTube входить через Google. AddSession показує форму входу, навіть якщо в браузері вже є інший Google-акаунт.
  // Куки Google не чистимо, щоб не розлогінити Gmail та інші сервіси.
  youtube:   { url: 'https://accounts.google.com/AddSession?service=youtube&continue=https%3A%2F%2Fwww.youtube.com%2F', cookieDomains: [] }
};
const JOB_TTL = 3 * 60 * 1000;
const BRIDGE_ID = 'agromegaa-bridge';

const str = (v, max = 300) => (typeof v === 'string' && v.length <= max ? v : '');

async function getSettings() {
  return chrome.storage.local.get({ clearSession: true, siteOrigin: '' });
}

// Вихід з попереднього акаунта платформи: видаляємо її куки (щоб увійти в інший акаунт)
async function clearCookies(domains) {
  for (const domain of domains) {
    const cookies = await chrome.cookies.getAll({ domain });
    await Promise.all(cookies.map(c => {
      const url = (c.secure ? 'https://' : 'http://') + c.domain.replace(/^\./, '') + c.path;
      return chrome.cookies.remove({ url, name: c.name, storeId: c.storeId }).catch(() => null);
    }));
  }
}

async function handleLogin(msg, sender) {
  const s = await getSettings();
  // Команду приймаємо лише від підключеного сайту
  let origin = '';
  try { origin = new URL(sender.url || '').origin; } catch { /* порожньо */ }
  if (!sender.tab || !s.siteOrigin || origin !== s.siteOrigin) return { ok: false, error: 'Сайт не підключено до розширення' };

  const a = msg.account || {};
  const platform = str(a.platform, 20);
  if (!LOGIN[platform]) return { ok: false, error: 'Невідома платформа' };
  const identifier = str(a.identifier), password = str(a.password, 500), secondary = str(a.secondary);
  if (!identifier || !password) return { ok: false, error: 'Немає логіна або пароля' };

  if (s.clearSession && LOGIN[platform].cookieDomains.length) await clearCookies(LOGIN[platform].cookieDomains);

  const tab = await chrome.tabs.create({ url: LOGIN[platform].url, active: true });
  await chrome.storage.session.set({ ['job:' + tab.id]: { platform, identifier, secondary, password, t: Date.now() } });
  return { ok: true };
}

async function handleGetJob(sender) {
  if (!sender.tab) return { ok: false };
  const key = 'job:' + sender.tab.id;
  const got = await chrome.storage.session.get(key);
  const job = got[key];
  if (!job) return { ok: false };
  if (Date.now() - job.t > JOB_TTL) { await chrome.storage.session.remove(key); return { ok: false }; }
  return { ok: true, job };
}

async function registerSite(origin) {
  const u = new URL(origin);
  if (!(u.protocol === 'https:' || (u.protocol === 'http:' && u.hostname === 'localhost'))) throw new Error('Потрібна адреса з https://');
  try { await chrome.scripting.unregisterContentScripts({ ids: [BRIDGE_ID] }); } catch { /* ще не було */ }
  await chrome.scripting.registerContentScripts([{
    id: BRIDGE_ID, matches: [u.origin + '/*'], js: ['content-site.js'], runAt: 'document_start', persistAcrossSessions: true
  }]);
  await chrome.storage.local.set({ siteOrigin: u.origin });
  // Підключаємо до вкладок сайту, які вже відкриті
  const tabs = await chrome.tabs.query({ url: u.origin + '/*' });
  for (const t of tabs) {
    try { await chrome.scripting.executeScript({ target: { tabId: t.id }, files: ['content-site.js'] }); } catch { /* вкладка недоступна */ }
  }
}

async function unregisterSite() {
  try { await chrome.scripting.unregisterContentScripts({ ids: [BRIDGE_ID] }); } catch { /* ok */ }
  const s = await getSettings();
  if (s.siteOrigin) { try { await chrome.permissions.remove({ origins: [s.siteOrigin + '/*'] }); } catch { /* ok */ } }
  await chrome.storage.local.set({ siteOrigin: '' });
}

chrome.runtime.onMessage.addListener((msg, sender, send) => {
  (async () => {
    try {
      // Налаштування змінює лише сторінка самого розширення
      const fromExt = sender.url && sender.url.startsWith(chrome.runtime.getURL(''));
      if (msg.type === 'LOGIN') return send(await handleLogin(msg, sender));
      if (msg.type === 'GET_JOB') return send(await handleGetJob(sender));
      if (msg.type === 'DONE') { if (sender.tab) await chrome.storage.session.remove('job:' + sender.tab.id); return send({ ok: true }); }
      if (msg.type === 'REGISTER_SITE' && fromExt) { await registerSite(String(msg.origin)); return send({ ok: true }); }
      if (msg.type === 'UNREGISTER_SITE' && fromExt) { await unregisterSite(); return send({ ok: true }); }
      send({ ok: false, error: 'Невідома команда' });
    } catch (e) {
      send({ ok: false, error: String((e && e.message) || e) });
    }
  })();
  return true;
});

chrome.tabs.onRemoved.addListener(id => { chrome.storage.session.remove('job:' + id).catch(() => {}); });
chrome.action.onClicked.addListener(() => chrome.runtime.openOptionsPage());
chrome.runtime.onInstalled.addListener(d => { if (d.reason === 'install') chrome.runtime.openOptionsPage(); });
