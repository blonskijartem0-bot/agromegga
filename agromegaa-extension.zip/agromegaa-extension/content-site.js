/* agromegaa автовхід — міст між сайтом agromegaa і розширенням.
   Працює тільки на адресі сайту, яку ти підключив у налаштуваннях розширення.
   Пароль передається лише тоді, коли ти натискаєш «Увійти в акаунт». */
(() => {
  if (window.__agroBridge) return;
  window.__agroBridge = true;
  const target = location.origin === 'null' ? '*' : location.origin;
  const version = chrome.runtime.getManifest().version;
  const say = (id, m) => window.postMessage({ source: 'agromegaa-ext', id, ...m }, target);

  window.addEventListener('message', async e => {
    if (e.source !== window) return;
    const d = e.data;
    if (!d || d.source !== 'agromegaa-site') return;
    if (d.type === 'PING') { say(d.id, { type: 'PONG', version }); return; }
    if (d.type === 'LOGIN') {
      try {
        const r = await chrome.runtime.sendMessage({ type: 'LOGIN', account: d.account });
        say(d.id, { type: 'LOGIN_ACK', ok: !!(r && r.ok), error: r && r.error });
      } catch (err) {
        say(d.id, { type: 'LOGIN_ACK', ok: false, error: String((err && err.message) || err) });
      }
    }
  });
  say(undefined, { type: 'PONG', version });
})();
