/* agromegaa автовхід — автозаповнення сторінки входу.
   Нічого не робить, доки сайт agromegaa не дав команду «увійти» саме для цієї вкладки.
   Логін і пароль вводяться лише на сторінці потрібної платформи. */
(async () => {
  let res;
  try { res = await chrome.runtime.sendMessage({ type: 'GET_JOB' }); } catch { return; }
  if (!res || !res.ok) return;
  const job = res.job;

  // Захист: дані можна вводити тільки на домені тієї платформи, для якої створено завдання
  const hostOk = {
    tiktok: /(^|\.)tiktok\.com$/,
    instagram: /(^|\.)instagram\.com$/,
    twitter: /(^|\.)(x|twitter)\.com$/,
    youtube: /^(accounts\.google\.com|(www\.)?youtube\.com)$/
  }[job.platform];
  if (!hostOk || !hostOk.test(location.hostname)) return;

  const twoStep = job.platform === 'twitter' || job.platform === 'youtube';
  const ID_SEL = {
    tiktok: ['input[name="username"]', 'input[type="email"]', 'input[autocomplete="username"]', 'input[placeholder*="mail" i]', 'input[type="text"]'],
    instagram: ['input[name="username"]', 'input[name="email"]', 'input[autocomplete="username"]', 'input[type="text"]'],
    twitter: ['input[autocomplete="username"]', 'input[name="text"]', 'input[type="text"]'],
    youtube: ['input#identifierId', 'input[type="email"]', 'input[name="identifier"]']
  }[job.platform];

  const sleep = ms => new Promise(r => setTimeout(r, ms));
  const isVis = el => {
    if (!el || el.disabled || el.readOnly) return false;
    const r = el.getBoundingClientRect(), cs = getComputedStyle(el);
    return r.width > 0 && r.height > 0 && cs.visibility !== 'hidden' && cs.display !== 'none';
  };
  const find = sels => { for (const s of sels) for (const el of document.querySelectorAll(s)) if (isVis(el)) return el; return null; };
  // Нативний setter, щоб React/Angular-форми побачили нове значення
  const setVal = (el, v) => {
    el.focus();
    Object.getOwnPropertyDescriptor(Object.getPrototypeOf(el), 'value').set.call(el, v);
    el.dispatchEvent(new Event('input', { bubbles: true }));
    el.dispatchEvent(new Event('change', { bubbles: true }));
  };

  const bar = document.createElement('div');
  bar.style.cssText = 'position:fixed;z-index:2147483647;top:12px;right:12px;max-width:320px;padding:10px 14px;border-radius:10px;background:#111;color:#fff;font:14px/1.4 system-ui,sans-serif;border:1px solid #e11d2e;box-shadow:0 6px 24px rgba(0,0,0,.5)';
  const say = t => { bar.textContent = 'agromegaa: ' + t; if (!bar.isConnected) document.documentElement.append(bar); };

  const EXPLICIT = ['#identifierNext button', '#identifierNext', '#passwordNext button', '#passwordNext',
    'button[data-e2e="login-button"]', '[data-testid="LoginForm_Login_Button"]', '[data-testid="ocfEnterTextNextButton"]'];
  const LABEL = /^(log ?in|sign ?in|next|continue|submit|увійти|далі|продовжити|войти|далее)$/i;
  function submit(anchor) {
    let btn = find(EXPLICIT);
    if (!btn) btn = [...document.querySelectorAll('button,[role="button"]')].find(b => isVis(b) && LABEL.test((b.innerText || b.textContent || '').trim()));
    if (btn) { btn.click(); return; }
    const form = anchor && anchor.closest && anchor.closest('form');
    if (form && form.requestSubmit) { form.requestSubmit(); return; }
    if (anchor) ['keydown', 'keypress', 'keyup'].forEach(t => anchor.dispatchEvent(new KeyboardEvent(t, { key: 'Enter', code: 'Enter', keyCode: 13, which: 13, bubbles: true })));
  }

  say('виконується автовхід…');
  let idDone = false, pwDone = false, secondDone = false, idAt = 0;
  const deadline = Date.now() + 90000;
  while (Date.now() < deadline) {
    const pw = find(['input[type="password"]']);
    const idEl = find(ID_SEL);

    if (pw && !pwDone) {
      // Форма з обома полями на одній сторінці (TikTok, Instagram)
      if (idEl && !idDone && idEl !== pw && !idEl.value) { setVal(idEl, job.identifier); idDone = true; await sleep(300); }
      setVal(pw, job.password); pwDone = true;
      say('пароль введено, входжу…');
      await sleep(450);
      submit(pw);
      say('готово. Якщо зʼявиться капча або код підтвердження, введи їх самостійно.');
      break;
    }
    if (!pw && idEl && !idDone) {
      setVal(idEl, job.identifier); idDone = true; idAt = Date.now();
      say('логін введено…');
      await sleep(450);
      if (twoStep) submit(idEl);
    } else if (!pw && idDone && !pwDone) {
      if (!twoStep && Date.now() - idAt > 3000 && idAt) { submit(idEl); idAt = 0; }
      // X іноді просить ще раз ввести нік або телефон
      if (job.platform === 'twitter' && !secondDone && Date.now() - idAt > 2500) {
        const el = find(['input[data-testid="ocfEnterTextTextInput"]', 'input[name="text"]']);
        if (el && !el.value) { setVal(el, job.secondary || job.identifier); secondDone = true; await sleep(300); submit(el); idAt = Date.now(); }
      }
    }
    await sleep(400);
  }
  if (!pwDone) say('не вдалося знайти форму входу. Введи дані вручну.');
  try { await chrome.runtime.sendMessage({ type: 'DONE' }); } catch { /* ok */ }
  setTimeout(() => bar.remove(), 12000);
})();
